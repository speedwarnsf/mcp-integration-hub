#!/usr/bin/env node

// Keychain Helper - Reads API keys from Mac Keychain
import { execSync } from 'child_process';

export function getAPIKey(keyName) {
  try {
    // Try to get key from Keychain with MCP-Hub prefix
    const result = execSync(
      `security find-generic-password -s "MCP-Hub-${keyName}" -w 2>/dev/null`,
      { encoding: 'utf8' }
    ).trim();
    return result || null;
  } catch {
    // Try environment variable as fallback
    return process.env[keyName] || null;
  }
}

export function getAllAPIKeys() {
  const keys = {};
  
  // List of known API key names
  const keyNames = [
    'OPENAI_API_KEY',
    'ANTHROPIC_API_KEY',
    'GEMINI_API_KEY',
    'VERCEL_TOKEN',
    'GITHUB_TOKEN',
    'STRIPE_SECRET_KEY',
    'FIREBASE_PROJECT_ID',
    'GOOGLE_API_KEY',
    'GODADDY_API_KEY',
    'BUBBLE_API_TOKEN',
    'EXPO_TOKEN',
    'SUPABASE_ANON_KEY',
    'MIDJOURNEY_TOKEN',
    'ELEVENLABS_API_KEY'
  ];
  
  for (const keyName of keyNames) {
    const value = getAPIKey(keyName);
    if (value) {
      keys[keyName] = value;
    }
  }
  
  return keys;
}

// Test function to verify Keychain access
export function testKeychainAccess() {
  const testKey = getAPIKey('OPENAI_API_KEY');
  if (testKey) {
    return `✅ Keychain access working! Found ${testKey.substring(0, 8)}...`;
  }
  return '⚠️ No API keys found in Keychain';
}
