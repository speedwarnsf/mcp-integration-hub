#!/bin/bash

# MCP Integration Hub Launcher
# This script is called by Claude Desktop to start the MCP server

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# Check if node_modules exists, if not install dependencies
if [ ! -d "$SCRIPT_DIR/node_modules" ]; then
    echo "Installing MCP dependencies..." >&2
    cd "$SCRIPT_DIR"
    npm install --silent 2>&1
fi

# Start the MCP server
cd "$SCRIPT_DIR"
exec node mcp-server.js
