// MCP Integration Hub - Max Security Edition
// Enhanced renderer with .env import functionality

const fs = require('fs');
const path = require('path');

// Previous code remains, adding new import functions...

// ENV File Import System
async function importEnvFile() {
    const modal = createImportModal();
    document.body.appendChild(modal);
}

function createImportModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay active';
    modal.innerHTML = `
        <div class="modal">
            <div class="modal-header">
                <span class="modal-icon">📁</span>
                <h2 class="modal-title">Import .env File</h2>
                <button class="modal-close" onclick="closeImportModal()">×</button>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 20px; color: rgba(255,255,255,0.7);">
                    Select your .env file to import all API keys at once. Keys will be encrypted and stored securely in your Mac Keychain.
                </p>
                <div class="input-group">
                    <label class="input-label">
                        <div style="padding: 40px; background: rgba(102, 126, 234, 0.1); border: 2px dashed rgba(102, 126, 234, 0.3); border-radius: 10px; text-align: center; cursor: pointer;">
                            <input type="file" id="envFileInput" accept=".env,text/plain" style="display: none;" onchange="handleEnvFile(event)">
                            <div style="font-size: 48px; margin-bottom: 10px;">📄</div>
                            <div style="font-size: 16px; color: #667eea;">Click to select .env file</div>
                            <div style="font-size: 12px; color: rgba(255,255,255,0.5); margin-top: 10px;">or drag and drop here</div>
                        </div>
                    </label>
                    <div id="importPreview" style="margin-top: 20px; display: none;">
                        <div style="background: rgba(16, 185, 129, 0.1); padding: 15px; border-radius: 10px; border-left: 3px solid #10b981;">
                            <div style="font-size: 14px; color: #10b981; margin-bottom: 10px;">✅ File loaded! Found keys:</div>
                            <div id="keysList" style="font-family: 'Monaco', monospace; font-size: 12px;"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-actions">
                <button class="modal-btn modal-btn-secondary" onclick="closeImportModal()">Cancel</button>
                <button class="modal-btn modal-btn-primary" id="importBtn" onclick="executeImport()" disabled>
                    🔐 Securely Import All Keys
                </button>
            </div>
        </div>
    `;
    return modal;
}

let envData = {};

function handleEnvFile(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        envData = parseEnvFile(content);
        
        // Show preview
        const preview = document.getElementById('importPreview');
        const keysList = document.getElementById('keysList');
        const importBtn = document.getElementById('importBtn');
        
        preview.style.display = 'block';
        
        // Display found keys (but not their values!)
        const keys = Object.keys(envData);
        keysList.innerHTML = keys.map(key => {
            const serviceName = detectService(key);
            return `<div style="margin: 5px 0;">
                <span style="color: #667eea;">${key}</span> 
                → 
                <span style="color: #10b981;">${serviceName}</span>
                <span style="color: rgba(255,255,255,0.3);"> (${envData[key].length} chars)</span>
            </div>`;
        }).join('');
        
        importBtn.disabled = false;
        importBtn.innerHTML = `🔐 Import ${keys.length} API Keys Securely`;
    };
    reader.readAsText(file);
}

function parseEnvFile(content) {
    const lines = content.split('\n');
    const env = {};
    
    lines.forEach(line => {
        // Skip comments and empty lines
        if (line.startsWith('#') || !line.trim()) return;
        
        const [key, ...valueParts] = line.split('=');
        if (key && valueParts.length > 0) {
            const value = valueParts.join('=').trim().replace(/^["']|["']$/g, '');
            env[key.trim()] = value;
        }
    });
    
    return env;
}

function detectService(keyName) {
    const mappings = {
        'GITHUB': 'github',
        'OPENAI': 'openai',
        'STRIPE': 'stripe',
        'GOOGLE': 'google',
        'GMAIL': 'gmail',
        'ANTHROPIC': 'anthropic',
        'SPOTIFY': 'spotify',
        'MIDJOURNEY': 'midjourney',
        'DOCKER': 'docker',
        'AWS': 'aws',
        'AZURE': 'azure'
    };
    
    const upperKey = keyName.toUpperCase();
    for (const [pattern, service] of Object.entries(mappings)) {
        if (upperKey.includes(pattern)) {
            return service;
        }
    }
    
    return 'custom';
}

async function executeImport() {
    const importBtn = document.getElementById('importBtn');
    importBtn.disabled = true;
    importBtn.innerHTML = '🔄 Encrypting and storing keys...';
    
    let successCount = 0;
    let failCount = 0;
    
    for (const [key, value] of Object.entries(envData)) {
        const serviceName = detectService(key);
        
        try {
            // Store in Keychain via main process
            const result = await window.mcpHub.saveAPIKey(serviceName, value, {
                envKey: key,
                imported: true,
                timestamp: new Date().toISOString()
            });
            
            if (result.success) {
                successCount++;
                
                // Mark service as configured
                activeIntegrations[serviceName] = {
                    configured: true,
                    enabled: true,
                    envKey: key
                };
            } else {
                failCount++;
            }
        } catch (error) {
            console.error(`Failed to import ${key}:`, error);
            failCount++;
        }
    }
    
    // Show results
    importBtn.innerHTML = `✅ Imported ${successCount} keys`;
    if (failCount > 0) {
        importBtn.innerHTML += ` (${failCount} failed)`;
    }
    
    // Refresh UI
    setTimeout(() => {
        closeImportModal();
        showCategory(currentCategory);
        updateStats();
        showNotification(`🔐 Successfully imported ${successCount} API keys securely!`, 'success');
        
        // Start Docker security bridge
        startDockerBridge();
    }, 1500);
}

function closeImportModal() {
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        if (modal.querySelector('.modal-title')?.textContent.includes('Import')) {
            modal.remove();
        }
    });
}

// Docker Security Bridge Management
async function startDockerBridge() {
    showNotification('🐳 Starting Docker Security Bridge...', 'info');
    
    try {
        const result = await window.mcpHub.startDockerBridge();
        if (result.success) {
            showNotification('✅ Docker Security Bridge is running!', 'success');
            updateBridgeStatus(true);
        } else {
            showNotification('❌ Failed to start Docker Bridge', 'error');
        }
    } catch (error) {
        console.error('Docker bridge error:', error);
    }
}

function updateBridgeStatus(running) {
    const statusIndicator = document.getElementById('bridgeStatus');
    if (statusIndicator) {
        statusIndicator.innerHTML = running ? 
            '🟢 Security Bridge: Active' : 
            '🔴 Security Bridge: Inactive';
        statusIndicator.style.color = running ? '#10b981' : '#ef4444';
    }
}

// Add Import Button to the UI
function addImportButton() {
    const header = document.querySelector('.header');
    if (header && !document.getElementById('importButton')) {
        const importBtn = document.createElement('button');
        importBtn.id = 'importButton';
        importBtn.className = 'import-env-button';
        importBtn.innerHTML = '📁 Import .env File';
        importBtn.onclick = importEnvFile;
        importBtn.style.cssText = `
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
            margin-left: 20px;
            transition: all 0.3s ease;
        `;
        
        header.appendChild(importBtn);
    }
    
    // Add Security Bridge Status
    if (!document.getElementById('bridgeStatus')) {
        const statusDiv = document.createElement('div');
        statusDiv.id = 'bridgeStatus';
        statusDiv.style.cssText = `
            position: fixed;
            bottom: 20px;
            left: 20px;
            padding: 10px 15px;
            background: rgba(0,0,0,0.8);
            border-radius: 20px;
            font-size: 12px;
            color: #ef4444;
        `;
        statusDiv.innerHTML = '🔴 Security Bridge: Inactive';
        document.body.appendChild(statusDiv);
    }
}

// Modify the init function to add import button
const originalInit = init;
init = async function() {
    await originalInit();
    addImportButton();
    
    // Check Docker bridge status
    const bridgeStatus = await window.mcpHub.checkDockerBridge();
    updateBridgeStatus(bridgeStatus.running);
};

// Global functions for onclick handlers
window.handleEnvFile = handleEnvFile;
window.executeImport = executeImport;
window.closeImportModal = closeImportModal;
window.importEnvFile = importEnvFile;

// Auto-start security features
document.addEventListener('DOMContentLoaded', () => {
    // Check if this is first run after import
    const imported = localStorage.getItem('keysImported');
    if (imported === 'true') {
        startDockerBridge();
        localStorage.removeItem('keysImported');
    }
});
