// MCP Integration Hub - Production Renderer
let apiCatalog = {};
let currentCategory = 'existing';
let activeIntegrations = {};
let currentProfile = 'default';
let currentServiceId = null;
let currentServiceName = null;
let isFirstRun = false;
let wizardStep = 1;

// API Key formats for validation
const API_KEY_FORMATS = {
    openai: { 
        pattern: /^sk-[A-Za-z0-9]{48}$/, 
        hint: "Format: sk-XXXXXXXX... (51 characters)",
        testEndpoint: "https://api.openai.com/v1/models",
        headers: { "Authorization": "Bearer {key}" }
    },
    github: { 
        pattern: /^gh[ps]_[A-Za-z0-9]{36}$/, 
        hint: "Format: ghp_XXXXX... or ghs_XXXXX... (40 characters)",
        testEndpoint: "https://api.github.com/user",
        headers: { "Authorization": "token {key}" }
    },
    stripe: { 
        pattern: /^(sk|pk)_(test_|live_)[A-Za-z0-9]{24,}$/, 
        hint: "Format: sk_test_XXXXX... or sk_live_XXXXX...",
        testEndpoint: "https://api.stripe.com/v1/charges",
        headers: { "Authorization": "Bearer {key}" }
    },
    midjourney: { 
        pattern: /^[A-Za-z0-9\-_]{20,}$/, 
        hint: "Enter your Midjourney API token",
        testEndpoint: null // Custom test
    },
    gmail: { 
        pattern: /^[A-Za-z0-9\-_\.]+$/, 
        hint: "Enter your Gmail API credentials or OAuth token",
        testEndpoint: "https://www.googleapis.com/gmail/v1/users/me/profile",
        headers: { "Authorization": "Bearer {key}" }
    },
    spotify: { 
        pattern: /^[A-Za-z0-9\-_]{20,}$/, 
        hint: "Enter your Spotify access token",
        testEndpoint: "https://api.spotify.com/v1/me",
        headers: { "Authorization": "Bearer {key}" }
    },
    default: { 
        pattern: /^.{10,}$/, 
        hint: "Enter your API key (minimum 10 characters)",
        testEndpoint: null
    }
};

// Initialize the application
async function init() {
    console.log('🚀 Initializing MCP Integration Hub...');
    
    // Check if it's first run
    isFirstRun = await checkFirstRun();
    
    if (isFirstRun) {
        console.log('📋 First run detected - showing setup wizard');
        showSetupWizard();
        return;
    }
    
    // Check MCP server connection
    const mcpConnected = await checkMCPServer();
    if (!mcpConnected) {
        showNotification('⚠️ MCP server not found at ~/mcp-final/', 'warning');
    }
    
    // Load API catalog
    apiCatalog = await window.mcpHub.getAPICatalog();
    
    // Load active integrations
    activeIntegrations = await window.mcpHub.getActiveIntegrations();
    
    // Get current profile
    currentProfile = await window.mcpHub.getCurrentProfile();
    updateProfileDisplay();
    
    // Load usage stats
    updateUsageStats();
    
    // Render categories
    renderCategories();
    
    // Show existing integrations by default
    showCategory('existing');
    
    // Set up event listeners
    setupEventListeners();
    
    // Update stats
    updateStats();
    
    console.log('✅ Initialization complete');
}

// Get current username for path suggestion
function getCurrentUsername() {
    // Try to get from localStorage or use a default
    const savedUsername = localStorage.getItem('username');
    if (savedUsername) return savedUsername;
    
    // Try to guess from common patterns
    const pathname = window.location.pathname;
    const match = pathname.match(/\/Users\/([^\/]+)/);
    if (match) {
        localStorage.setItem('username', match[1]);
        return match[1];
    }
    
    // Default
    return 'your-username';
}

// Check if this is the first run
async function checkFirstRun() {
    try {
        const hasRunBefore = localStorage.getItem('mcp-hub-initialized');
        return !hasRunBefore;
    } catch (e) {
        return false;
    }
}

// Check MCP server connection
async function checkMCPServer() {
    try {
        // Don't block app startup if this fails
        const result = await window.mcpHub.checkMCPServer().catch(() => ({ connected: false }));
        return result.connected;
    } catch (e) {
        console.error('Error checking MCP server:', e);
        return false;
    }
}

// Setup Wizard Functions
function showSetupWizard() {
    const wizard = document.getElementById('setupWizard');
    wizard.classList.add('active');
    showWizardStep(1);
    
    // Add ESC key handler to skip wizard
    const handleEsc = (e) => {
        if (e.key === 'Escape' && wizard.classList.contains('active')) {
            skipWizard();
            document.removeEventListener('keydown', handleEsc);
        }
    };
    document.addEventListener('keydown', handleEsc);
}

function showWizardStep(step) {
    wizardStep = step;
    const content = document.getElementById('wizardContent');
    
    // Update progress indicators
    for (let i = 1; i <= 4; i++) {
        const stepEl = document.getElementById(`wizStep${i}`);
        if (stepEl) {
            stepEl.classList.remove('active', 'completed');
            if (i < step) stepEl.classList.add('completed');
            if (i === step) stepEl.classList.add('active');
        }
    }
    
    try {
        switch(step) {
            case 1:
                content.innerHTML = `
                    <h1 style="margin-bottom: 20px;">🚀 Welcome to MCP Integration Hub!</h1>
                    <p style="margin-bottom: 30px; color: rgba(255,255,255,0.7); line-height: 1.6;">
                        This hub lets you connect Claude to hundreds of services, manage multiple identities, 
                        and control all your API integrations from one beautiful interface.
                    </p>
                    <div style="background: rgba(102, 126, 234, 0.1); padding: 20px; border-radius: 10px; margin-bottom: 30px;">
                        <h3 style="margin-bottom: 15px;">✨ Key Features</h3>
                        <ul style="list-style: none; padding: 0;">
                            <li style="margin-bottom: 10px;">🔐 Secure API key storage in Mac Keychain</li>
                            <li style="margin-bottom: 10px;">👥 Multiple identity profiles</li>
                            <li style="margin-bottom: 10px;">🔄 Toggle integrations on/off instantly</li>
                            <li style="margin-bottom: 10px;">🎨 100+ pre-configured services</li>
                        </ul>
                    </div>
                    <div style="display: flex; gap: 10px;">
                        <button class="modal-btn modal-btn-primary" style="flex: 1;" onclick="showWizardStep(2)">
                            Let's Get Started →
                        </button>
                        <button class="modal-btn modal-btn-secondary" onclick="skipWizard()">
                            Skip Setup
                        </button>
                    </div>
                `;
                break;
            
        case 2:
            content.innerHTML = `
                <h2 style="margin-bottom: 20px;">⚙️ MCP Server Setup</h2>
                <p style="margin-bottom: 30px; color: rgba(255,255,255,0.7);">
                    The hub needs to connect to your MCP server to manage integrations.
                </p>
                <div class="input-group">
                    <label class="input-label">MCP Server Path</label>
                    <input type="text" 
                           class="modal-input" 
                           id="mcpPathInput" 
                           value="/Users/${getCurrentUsername()}/mcp-final" 
                           placeholder="/path/to/mcp-server">
                    <div style="margin-top: 10px;">
                        <button class="modal-btn modal-btn-test" onclick="testMCPConnection()">
                            🔍 Test Connection
                        </button>
                    </div>
                    <div class="validation-message" id="mcpValidation"></div>
                </div>
                <div style="display: flex; gap: 10px; margin-top: 30px;">
                    <button class="modal-btn modal-btn-secondary" onclick="showWizardStep(1)">
                        ← Back
                    </button>
                    <button class="modal-btn modal-btn-primary" onclick="saveMCPPath()">
                        Continue →
                    </button>
                    <button class="modal-btn modal-btn-secondary" onclick="skipWizard()">
                        Skip Setup
                    </button>
                </div>
            `;
            break;
            
        case 3:
            content.innerHTML = `
                <h2 style="margin-bottom: 20px;">👥 Profile Setup</h2>
                <p style="margin-bottom: 30px; color: rgba(255,255,255,0.7);">
                    Create profiles to manage different sets of API integrations. 
                    You can switch between profiles anytime.
                </p>
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px; margin-bottom: 30px;">
                    <div class="profile-card" style="padding: 20px; background: rgba(255,255,255,0.05); border-radius: 10px; cursor: pointer; transition: all 0.3s;" 
                         onmouseover="this.style.background='rgba(102,126,234,0.2)'" 
                         onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                        <div style="font-size: 30px; margin-bottom: 10px;">💼</div>
                        <div style="font-weight: 600;">Professional</div>
                        <div style="font-size: 12px; color: rgba(255,255,255,0.5);">Work & Business</div>
                    </div>
                    <div class="profile-card" style="padding: 20px; background: rgba(255,255,255,0.05); border-radius: 10px; cursor: pointer; transition: all 0.3s;"
                         onmouseover="this.style.background='rgba(102,126,234,0.2)'" 
                         onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                        <div style="font-size: 30px; margin-bottom: 10px;">🎨</div>
                        <div style="font-weight: 600;">Creative</div>
                        <div style="font-size: 12px; color: rgba(255,255,255,0.5);">Art & Music</div>
                    </div>
                    <div class="profile-card" style="padding: 20px; background: rgba(255,255,255,0.05); border-radius: 10px; cursor: pointer; transition: all 0.3s;"
                         onmouseover="this.style.background='rgba(102,126,234,0.2)'" 
                         onmouseout="this.style.background='rgba(255,255,255,0.05)'">
                        <div style="font-size: 30px; margin-bottom: 10px;">🏠</div>
                        <div style="font-weight: 600;">Personal</div>
                        <div style="font-size: 12px; color: rgba(255,255,255,0.5);">Private Use</div>
                    </div>
                    <div class="profile-card" style="padding: 20px; background: rgba(102,126,234,0.2); border: 1px solid rgba(102,126,234,0.5); border-radius: 10px;">
                        <div style="font-size: 30px; margin-bottom: 10px;">⚡</div>
                        <div style="font-weight: 600;">Default</div>
                        <div style="font-size: 12px; color: rgba(255,255,255,0.5);">Selected</div>
                    </div>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button class="modal-btn modal-btn-secondary" onclick="showWizardStep(2)">
                        ← Back
                    </button>
                    <button class="modal-btn modal-btn-primary" onclick="showWizardStep(4)">
                        Continue →
                    </button>
                </div>
            `;
            break;
            
        case 4:
            content.innerHTML = `
                <h2 style="margin-bottom: 20px;">🎯 Configure Your First Integration</h2>
                <p style="margin-bottom: 30px; color: rgba(255,255,255,0.7);">
                    Let's set up your first API integration. You can add more later from the main interface.
                </p>
                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 30px;">
                    <button class="service-quick-add" onclick="quickAddService('openai')" 
                            style="padding: 20px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; cursor: pointer; color: white; transition: all 0.3s;">
                        <div style="font-size: 30px; margin-bottom: 10px;">🤖</div>
                        <div>OpenAI</div>
                    </button>
                    <button class="service-quick-add" onclick="quickAddService('github')"
                            style="padding: 20px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; cursor: pointer; color: white; transition: all 0.3s;">
                        <div style="font-size: 30px; margin-bottom: 10px;">🐙</div>
                        <div>GitHub</div>
                    </button>
                    <button class="service-quick-add" onclick="quickAddService('gmail')"
                            style="padding: 20px; background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; cursor: pointer; color: white; transition: all 0.3s;">
                        <div style="font-size: 30px; margin-bottom: 10px;">📧</div>
                        <div>Gmail</div>
                    </button>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button class="modal-btn modal-btn-secondary" onclick="showWizardStep(3)">
                        ← Back
                    </button>
                    <button class="modal-btn modal-btn-secondary" onclick="skipWizard()">
                        Skip for Now
                    </button>
                    <button class="modal-btn modal-btn-primary" onclick="completeWizard()">
                        Complete Setup ✨
                    </button>
                </div>
            `;
            break;
        }
    } catch (error) {
        console.error('Error in wizard step:', error);
        content.innerHTML = `
            <h2 style="margin-bottom: 20px;">⚠️ Setup Error</h2>
            <p style="margin-bottom: 30px; color: rgba(255,255,255,0.7);">
                There was an issue with the setup wizard. You can skip it and configure settings manually.
            </p>
            <div style="display: flex; gap: 10px;">
                <button class="modal-btn modal-btn-primary" onclick="skipWizard()">
                    Skip Setup and Continue →
                </button>
                <button class="modal-btn modal-btn-secondary" onclick="showWizardStep(1)">
                    Try Again
                </button>
            </div>
        `;
    }
}

function testMCPConnection() {
    const path = document.getElementById('mcpPathInput').value;
    const validation = document.getElementById('mcpValidation');
    
    // Simulate testing connection
    setTimeout(() => {
        if (path.includes('mcp')) {
            validation.className = 'validation-message success';
            validation.textContent = '✅ MCP server found!';
            validation.style.display = 'block';
        } else {
            validation.className = 'validation-message error';
            validation.textContent = '❌ MCP server not found at this path';
            validation.style.display = 'block';
        }
    }, 500);
}

function saveMCPPath() {
    const path = document.getElementById('mcpPathInput').value;
    localStorage.setItem('mcp-server-path', path);
    showWizardStep(3);
}

function quickAddService(serviceId) {
    currentServiceId = serviceId;
    currentServiceName = serviceId.charAt(0).toUpperCase() + serviceId.slice(1);
    document.getElementById('setupWizard').classList.remove('active');
    openAPIModal(serviceId, currentServiceName);
}

function skipWizard() {
    completeWizard();
}

function completeWizard() {
    localStorage.setItem('mcp-hub-initialized', 'true');
    document.getElementById('setupWizard').classList.remove('active');
    init(); // Reinitialize the app
    showNotification('🎉 Setup complete! Welcome to MCP Integration Hub', 'success');
}

// Enhanced Modal Functions
function openAPIModal(serviceId, serviceName) {
    currentServiceId = serviceId;
    currentServiceName = serviceName;
    
    const modal = document.getElementById('apiKeyModal');
    const icon = document.getElementById('modalIcon');
    const title = document.getElementById('modalTitle');
    const input = document.getElementById('apiKeyInput');
    const hint = document.getElementById('formatHint');
    
    // Find service icon
    let serviceIcon = '🔑';
    Object.values(apiCatalog).forEach(category => {
        const service = category.services.find(s => s.id === serviceId);
        if (service) serviceIcon = service.icon;
    });
    
    icon.textContent = serviceIcon;
    title.textContent = `Configure ${serviceName}`;
    input.value = '';
    input.type = 'password';
    
    // Set format hint
    const format = API_KEY_FORMATS[serviceId] || API_KEY_FORMATS.default;
    hint.innerHTML = `💡 ${format.hint}`;
    
    // Reset validation
    document.getElementById('validationMessage').style.display = 'none';
    
    modal.classList.add('active');
    input.focus();
}

function closeAPIModal() {
    document.getElementById('apiKeyModal').classList.remove('active');
    currentServiceId = null;
    currentServiceName = null;
}

function toggleKeyVisibility() {
    const input = document.getElementById('apiKeyInput');
    const icon = document.getElementById('visibilityIcon');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.textContent = '🙈';
    } else {
        input.type = 'password';
        icon.textContent = '👁️';
    }
}

async function pasteFromClipboard() {
    try {
        const text = await navigator.clipboard.readText();
        document.getElementById('apiKeyInput').value = text;
        validateAPIKey();
        showNotification('📋 Pasted from clipboard', 'success');
    } catch (err) {
        showNotification('❌ Could not paste from clipboard', 'error');
    }
}

async function copyToClipboard() {
    const input = document.getElementById('apiKeyInput');
    try {
        await navigator.clipboard.writeText(input.value);
        showNotification('📄 Copied to clipboard', 'success');
    } catch (err) {
        showNotification('❌ Could not copy to clipboard', 'error');
    }
}

function validateAPIKey() {
    const input = document.getElementById('apiKeyInput').value;
    const validation = document.getElementById('validationMessage');
    const format = API_KEY_FORMATS[currentServiceId] || API_KEY_FORMATS.default;
    
    if (!input) {
        validation.style.display = 'none';
        return false;
    }
    
    if (format.pattern && !format.pattern.test(input)) {
        validation.className = 'validation-message error';
        validation.textContent = `❌ Invalid format. ${format.hint}`;
        validation.style.display = 'block';
        return false;
    }
    
    validation.className = 'validation-message success';
    validation.textContent = '✅ Format looks good!';
    validation.style.display = 'block';
    return true;
}

async function testAPIConnection() {
    const apiKey = document.getElementById('apiKeyInput').value;
    const validation = document.getElementById('validationMessage');
    const testBtn = document.getElementById('testBtn');
    
    if (!apiKey) {
        validation.className = 'validation-message error';
        validation.textContent = '❌ Please enter an API key first';
        validation.style.display = 'block';
        return;
    }
    
    // Disable button and show loading
    testBtn.disabled = true;
    testBtn.classList.add('modal-btn-loading');
    testBtn.textContent = '';
    
    // Get test configuration
    const format = API_KEY_FORMATS[currentServiceId] || API_KEY_FORMATS.default;
    
    try {
        if (format.testEndpoint) {
            // Real API test
            const headers = {};
            Object.entries(format.headers || {}).forEach(([key, value]) => {
                headers[key] = value.replace('{key}', apiKey);
            });
            
            const response = await fetch(format.testEndpoint, {
                method: 'GET',
                headers: headers
            });
            
            if (response.ok || response.status === 401) {
                if (response.ok) {
                    validation.className = 'validation-message success';
                    validation.textContent = '✅ Connection successful!';
                } else {
                    validation.className = 'validation-message error';
                    validation.textContent = '❌ Invalid API key';
                }
            } else {
                throw new Error(`HTTP ${response.status}`);
            }
        } else {
            // Simulate test for services without test endpoint
            await new Promise(resolve => setTimeout(resolve, 1500));
            validation.className = 'validation-message success';
            validation.textContent = '✅ Key format validated (live test not available)';
        }
    } catch (error) {
        validation.className = 'validation-message error';
        validation.textContent = `❌ Connection failed: ${error.message}`;
    } finally {
        // Re-enable button
        testBtn.disabled = false;
        testBtn.classList.remove('modal-btn-loading');
        testBtn.textContent = '🧪 Test Connection';
        validation.style.display = 'block';
    }
}

async function saveAPIKey() {
    const apiKey = document.getElementById('apiKeyInput').value;
    const saveBtn = document.getElementById('saveBtn');
    
    if (!apiKey) {
        const validation = document.getElementById('validationMessage');
        validation.className = 'validation-message error';
        validation.textContent = '❌ Please enter an API key';
        validation.style.display = 'block';
        return;
    }
    
    // Validate format
    if (!validateAPIKey()) {
        return;
    }
    
    // Show loading
    saveBtn.disabled = true;
    saveBtn.classList.add('modal-btn-loading');
    saveBtn.textContent = '';
    
    try {
        const result = await window.mcpHub.saveAPIKey(currentServiceId, apiKey);
        
        if (result.success) {
            activeIntegrations[currentServiceId] = {
                ...activeIntegrations[currentServiceId],
                configured: true
            };
            
            // Close modal and refresh UI
            closeAPIModal();
            showCategory(currentCategory);
            
            showNotification(`✅ ${currentServiceName} API key saved securely`, 'success');
        } else {
            throw new Error(result.error);
        }
    } catch (error) {
        showNotification(`❌ Failed to save API key: ${error.message}`, 'error');
    } finally {
        saveBtn.disabled = false;
        saveBtn.classList.remove('modal-btn-loading');
        saveBtn.textContent = '💾 Save Key';
    }
}

// Updated service configuration function
async function configureService(serviceId, serviceName) {
    openAPIModal(serviceId, serviceName);
}

// Render category sidebar
function renderCategories() {
    const categoryList = document.getElementById('categoryList');
    categoryList.innerHTML = '';
    
    Object.entries(apiCatalog).forEach(([key, category]) => {
        const item = document.createElement('div');
        item.className = `category-item ${key === currentCategory ? 'active' : ''}`;
        item.onclick = () => showCategory(key);
        
        const serviceCount = category.services.length;
        
        item.innerHTML = `
            <span class="category-icon">${category.icon}</span>
            <span class="category-name">${category.name}</span>
            <span class="category-count">${serviceCount}</span>
        `;
        
        categoryList.appendChild(item);
    });
}

// Show services for a category
function showCategory(categoryKey) {
    currentCategory = categoryKey;
    const category = apiCatalog[categoryKey];
    
    // Update header
    document.getElementById('categoryTitle').textContent = category.name;
    document.getElementById('categoryDescription').textContent = getCategoryDescription(categoryKey);
    
    // Update active category
    document.querySelectorAll('.category-item').forEach(item => {
        item.classList.remove('active');
    });
    document.querySelectorAll('.category-item')[Object.keys(apiCatalog).indexOf(categoryKey)].classList.add('active');
    
    // Render services
    renderServices(category.services);
}

// Get category descriptions
function getCategoryDescription(key) {
    const descriptions = {
        existing: 'Your currently configured integrations that are ready to use with Claude',
        productivity: 'Connect your productivity tools to automate workflows and access your data',
        creative: 'Integrate with creative platforms for AI-powered design and content generation',
        music: 'Connect to music platforms for distribution, streaming, and analytics',
        travel: 'Book flights, hotels, and transportation directly through Claude',
        shopping: 'Access marketplaces and shopping platforms for automated purchasing',
        specialized: 'Unique databases and specialized APIs for advanced use cases'
    };
    return descriptions[key] || 'Browse and enable integrations in this category';
}

// Render service cards
function renderServices(services) {
    const grid = document.getElementById('serviceGrid');
    grid.innerHTML = '';
    
    // Filter services based on search
    const searchTerm = document.getElementById('searchBar').value.toLowerCase();
    const filteredServices = services.filter(service => 
        service.name.toLowerCase().includes(searchTerm) ||
        service.id.toLowerCase().includes(searchTerm)
    );
    
    filteredServices.forEach(service => {
        const card = createServiceCard(service);
        grid.appendChild(card);
    });
    
    if (filteredServices.length === 0) {
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px; color: rgba(255,255,255,0.5);">
                <div style="font-size: 48px; margin-bottom: 20px;">🔍</div>
                <div style="font-size: 18px;">No integrations found matching "${searchTerm}"</div>
            </div>
        `;
    }
}

// Create a service card element
function createServiceCard(service) {
    const card = document.createElement('div');
    card.className = 'service-card';
    
    const isActive = activeIntegrations[service.id]?.enabled;
    const isConfigured = activeIntegrations[service.id]?.configured;
    
    card.innerHTML = `
        <div class="service-header">
            <span class="service-icon">${service.icon}</span>
            <div class="service-info">
                <div class="service-name">${service.name}</div>
                <span class="service-status status-${service.status}">${getStatusText(service.status)}</span>
            </div>
        </div>
        <div class="service-privacy privacy-${service.privacy}">
            🔒 Privacy: ${service.privacy.charAt(0).toUpperCase() + service.privacy.slice(1)}
        </div>
        <div class="service-actions">
            <div class="toggle-switch ${isActive ? 'active' : ''}" 
                 onclick="toggleService('${service.id}', ${!isActive})"
                 title="${isActive ? 'Disable' : 'Enable'} ${service.name}">
                <div class="toggle-slider"></div>
            </div>
            <button class="configure-button" onclick="configureService('${service.id}', '${service.name}')">
                ${isConfigured ? '⚙️ Reconfigure' : '🔑 Add API Key'}
            </button>
        </div>
    `;
    
    return card;
}

// Get status display text
function getStatusText(status) {
    const statusMap = {
        active: '✅ Active',
        available: '🟢 Available',
        coming: '🟡 Coming Soon',
        development: '🚧 In Development'
    };
    return statusMap[status] || status;
}

// Toggle service on/off
async function toggleService(serviceId, enable) {
    const result = await window.mcpHub.toggleIntegration(serviceId, enable);
    if (result.success) {
        activeIntegrations[serviceId] = {
            ...activeIntegrations[serviceId],
            enabled: enable
        };
        
        // Re-render current category
        showCategory(currentCategory);
        updateStats();
        
        // Show notification
        showNotification(`${enable ? 'Enabled' : 'Disabled'} integration`, 'success');
    }
}

// Update usage statistics
async function updateUsageStats() {
    const stats = await window.mcpHub.getUsageStats();
    const tracker = document.getElementById('usageTracker');
    
    const percentage = (stats.usage / stats.limit) * 100;
    const color = percentage > 80 ? '#ef4444' : percentage > 60 ? '#f59e0b' : '#10b981';
    
    tracker.innerHTML = `
        <span style="color: ${color}">💳 ${stats.credits} credits</span>
        <span style="opacity: 0.6"> (${percentage.toFixed(1)}%)</span>
    `;
}

// Update profile display
function updateProfileDisplay() {
    document.getElementById('currentProfile').textContent = `Profile: ${currentProfile.charAt(0).toUpperCase() + currentProfile.slice(1)}`;
}

// Update statistics
function updateStats() {
    let totalServices = 0;
    let activeServices = 0;
    
    Object.values(apiCatalog).forEach(category => {
        totalServices += category.services.length;
        category.services.forEach(service => {
            if (activeIntegrations[service.id]?.enabled) {
                activeServices++;
            }
        });
    });
    
    document.getElementById('activeCount').textContent = activeServices;
    document.getElementById('totalCount').textContent = totalServices;
}

// Enhanced notification with auto-dismiss
function showNotification(message, type) {
    // Remove any existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 20px;
        background: ${type === 'success' ? 'rgba(16, 185, 129, 0.2)' : 
                     type === 'warning' ? 'rgba(251, 146, 60, 0.2)' :
                     'rgba(239, 68, 68, 0.2)'};
        color: ${type === 'success' ? '#10b981' : 
                 type === 'warning' ? '#fb923c' :
                 '#ef4444'};
        border: 1px solid ${type === 'success' ? 'rgba(16, 185, 129, 0.5)' : 
                            type === 'warning' ? 'rgba(251, 146, 60, 0.5)' :
                            'rgba(239, 68, 68, 0.5)'};
        border-radius: 10px;
        font-size: 14px;
        z-index: 3000;
        animation: slideIn 0.3s ease;
        box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Auto-dismiss after 4 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 4000);
}

// Set up event listeners
function setupEventListeners() {
    // Search functionality
    document.getElementById('searchBar').addEventListener('input', () => {
        showCategory(currentCategory);
    });
    
    // API key input validation
    document.getElementById('apiKeyInput').addEventListener('input', validateAPIKey);
    
    // Keyboard shortcuts for modal
    document.getElementById('apiKeyInput').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            saveAPIKey();
        } else if (e.key === 'Escape') {
            closeAPIModal();
        }
    });
    
    // Profile switching
    document.getElementById('currentProfile').addEventListener('click', async () => {
        const profiles = ['default', 'professional', 'creative', 'personal'];
        const currentIndex = profiles.indexOf(currentProfile);
        const nextProfile = profiles[(currentIndex + 1) % profiles.length];
        
        const result = await window.mcpHub.switchProfile(nextProfile);
        if (result.success) {
            currentProfile = result.profile;
            updateProfileDisplay();
            
            // Reload integrations for new profile
            activeIntegrations = await window.mcpHub.getActiveIntegrations();
            showCategory(currentCategory);
            updateStats();
            
            showNotification(`Switched to ${nextProfile} profile`, 'success');
        }
    });
    
    // IPC event listeners
    window.mcpHub.onProfileSwitched((profile) => {
        currentProfile = profile;
        updateProfileDisplay();
        init(); // Reinitialize with new profile
    });
    
    window.mcpHub.onOpenPreferences(() => {
        // Open preferences dialog
        console.log('Opening preferences...');
    });
    
    window.mcpHub.onManageProfiles(() => {
        // Open profile management
        console.log('Managing profiles...');
    });
    
    // FAB click handler - Add custom integration
    document.querySelector('.fab').addEventListener('click', () => {
        showCustomIntegrationDialog();
    });
    
    // Close modals on outside click
    document.getElementById('apiKeyModal').addEventListener('click', (e) => {
        if (e.target.id === 'apiKeyModal') {
            closeAPIModal();
        }
    });
    
    // Periodic usage stats update
    setInterval(updateUsageStats, 60000); // Update every minute
}

// Custom Integration Dialog
function showCustomIntegrationDialog() {
    const content = `
        <h2>🔧 Add Custom Integration</h2>
        <p style="margin-bottom: 20px; color: rgba(255,255,255,0.7);">
            Add any API not in our catalog
        </p>
        <div class="input-group">
            <label class="input-label">Service Name</label>
            <input type="text" class="modal-input" id="customName" placeholder="e.g., My Custom API">
        </div>
        <div class="input-group">
            <label class="input-label">Icon (Emoji)</label>
            <input type="text" class="modal-input" id="customIcon" placeholder="e.g., 🚀" maxlength="2">
        </div>
        <div class="input-group">
            <label class="input-label">API Endpoint</label>
            <input type="text" class="modal-input" id="customEndpoint" placeholder="https://api.example.com">
        </div>
        <div class="modal-actions">
            <button class="modal-btn modal-btn-secondary" onclick="closeCustomDialog()">Cancel</button>
            <button class="modal-btn modal-btn-primary" onclick="addCustomIntegration()">Add Integration</button>
        </div>
    `;
    
    // Create and show modal
    const modal = document.createElement('div');
    modal.className = 'modal-overlay active';
    modal.innerHTML = `<div class="modal">${content}</div>`;
    document.body.appendChild(modal);
}

function closeCustomDialog() {
    document.querySelectorAll('.modal-overlay').forEach(m => {
        if (!m.id) m.remove();
    });
}

function addCustomIntegration() {
    const name = document.getElementById('customName').value;
    const icon = document.getElementById('customIcon').value || '🔧';
    const endpoint = document.getElementById('customEndpoint').value;
    
    if (name && endpoint) {
        // Add to catalog
        const customId = name.toLowerCase().replace(/\s+/g, '-');
        
        // Add to specialized category
        apiCatalog.specialized.services.push({
            id: customId,
            name: name,
            icon: icon,
            privacy: 'medium',
            status: 'available',
            endpoint: endpoint,
            custom: true
        });
        
        closeCustomDialog();
        showCategory('specialized');
        showNotification(`✅ Added custom integration: ${name}`, 'success');
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', init);

// Global functions for HTML onclick handlers
window.toggleService = toggleService;
window.configureService = configureService;
window.closeAPIModal = closeAPIModal;
window.toggleKeyVisibility = toggleKeyVisibility;
window.pasteFromClipboard = pasteFromClipboard;
window.copyToClipboard = copyToClipboard;
window.testAPIConnection = testAPIConnection;
window.saveAPIKey = saveAPIKey;
window.showWizardStep = showWizardStep;
window.testMCPConnection = testMCPConnection;
window.saveMCPPath = saveMCPPath;
window.quickAddService = quickAddService;
window.skipWizard = skipWizard;
window.completeWizard = completeWizard;
window.closeCustomDialog = closeCustomDialog;
window.addCustomIntegration = addCustomIntegration;
window.showCustomIntegrationDialog = showCustomIntegrationDialog;
