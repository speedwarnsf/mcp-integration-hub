const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const path = require('path');
const Store = require('electron-store');
const keytar = require('keytar');
const crypto = require('crypto');
const fs = require('fs');

// Initialize secure storage
const store = new Store({
  encryptionKey: 'mcp-hub-2025-secure',
  name: 'mcp-integrations'
});

let mainWindow;
let currentProfile = 'default';

// API Integration definitions
const API_CATALOG = {
  productivity: {
    name: 'Productivity',
    icon: '📊',
    services: [
      { id: 'gmail', name: 'Gmail', icon: '📧', privacy: 'high', status: 'available' },
      { id: 'gdrive', name: 'Google Drive', icon: '📁', privacy: 'high', status: 'available' },
      { id: 'calendar', name: 'iOS Calendar', icon: '📅', privacy: 'medium', status: 'available' },
      { id: 'notion', name: 'Notion', icon: '📝', privacy: 'medium', status: 'coming' },
    ]
  },
  creative: {
    name: 'Creative & Design',
    icon: '🎨',
    services: [
      { id: 'midjourney', name: 'Midjourney', icon: '🖼️', privacy: 'low', status: 'available' },
      { id: 'nannobannana', name: 'NannoBannana', icon: '🍌', privacy: 'low', status: 'available' },
      { id: 'envato', name: 'Envato', icon: '🎪', privacy: 'low', status: 'available' },
      { id: 'adobe', name: 'Adobe Creative Cloud', icon: '🎭', privacy: 'medium', status: 'available' },
      { id: 'elevenlabs', name: '11 Labs', icon: '🎙️', privacy: 'low', status: 'available' },
    ]
  },
  music: {
    name: 'Music Industry',
    icon: '🎵',
    services: [
      { id: 'spotify', name: 'Spotify', icon: '🎶', privacy: 'medium', status: 'available' },
      { id: 'applemusic', name: 'Apple Music', icon: '🍎', privacy: 'medium', status: 'available' },
      { id: 'unitedmasters', name: 'United Masters', icon: '👑', privacy: 'low', status: 'available' },
      { id: 'soundcloud', name: 'SoundCloud', icon: '☁️', privacy: 'low', status: 'available' },
    ]
  },
  travel: {
    name: 'Travel & Transport',
    icon: '✈️',
    services: [
      { id: 'waymo', name: 'Waymo', icon: '🚗', privacy: 'high', status: 'available' },
      { id: 'turo', name: 'Turo', icon: '🚙', privacy: 'medium', status: 'available' },
      { id: 'vrbo', name: 'VRBO', icon: '🏠', privacy: 'medium', status: 'available' },
      { id: 'airbnb', name: 'Airbnb', icon: '🏡', privacy: 'medium', status: 'available' },
      { id: 'kayak', name: 'Kayak', icon: '🛶', privacy: 'low', status: 'available' },
      { id: 'united', name: 'United Airlines', icon: '🛫', privacy: 'medium', status: 'available' },
    ]
  },
  shopping: {
    name: 'Shopping & Marketplace',
    icon: '🛍️',
    services: [
      { id: 'amazon', name: 'Amazon', icon: '📦', privacy: 'medium', status: 'available' },
      { id: 'ebay', name: 'eBay', icon: '🏷️', privacy: 'medium', status: 'available' },
      { id: 'etsy', name: 'Etsy', icon: '🧵', privacy: 'low', status: 'available' },
      { id: 'reverb', name: 'Reverb', icon: '🎸', privacy: 'low', status: 'available' },
      { id: 'craigslist', name: 'Craigslist', icon: '📋', privacy: 'high', status: 'available' },
      { id: 'threadup', name: 'Thread Up', icon: '👗', privacy: 'low', status: 'available' },
    ]
  },
  specialized: {
    name: 'Specialized Databases',
    icon: '🔬',
    services: [
      { id: 'grogsknots', name: "Grog's Knots", icon: '🪢', privacy: 'low', status: 'available' },
      { id: 'zillow', name: 'Zillow Property API', icon: '🏘️', privacy: 'medium', status: 'available' },
      { id: 'zenrows', name: 'ZenRows', icon: '🕷️', privacy: 'low', status: 'available' },
      { id: 'claude-usage', name: 'Claude Usage Tracker', icon: '📊', privacy: 'high', status: 'development' },
    ]
  },
  existing: {
    name: 'Currently Active',
    icon: '✅',
    services: [
      { id: 'docker', name: 'Docker', icon: '🐋', privacy: 'low', status: 'active' },
      { id: 'github', name: 'GitHub', icon: '🐙', privacy: 'medium', status: 'active' },
      { id: 'openai', name: 'OpenAI', icon: '🤖', privacy: 'medium', status: 'active' },
      { id: 'stripe', name: 'Stripe', icon: '💳', privacy: 'high', status: 'active' },
    ]
  }
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#0a0a0a',
    icon: path.join(__dirname, 'icon.png')
  });

  mainWindow.loadFile('index.html');

  // Create application menu
  const template = [
    {
      label: 'MCP Hub',
      submenu: [
        { label: 'About MCP Integration Hub', role: 'about' },
        { type: 'separator' },
        { label: 'Preferences', accelerator: 'Cmd+,', click: () => mainWindow.webContents.send('open-preferences') },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'Cmd+Q', click: () => app.quit() }
      ]
    },
    {
      label: 'Profile',
      submenu: [
        { label: 'Default', type: 'radio', checked: true, click: () => switchProfile('default') },
        { label: 'Professional', type: 'radio', click: () => switchProfile('professional') },
        { label: 'Creative', type: 'radio', click: () => switchProfile('creative') },
        { label: 'Personal', type: 'radio', click: () => switchProfile('personal') },
        { type: 'separator' },
        { label: 'Manage Profiles...', click: () => mainWindow.webContents.send('manage-profiles') }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Reload', accelerator: 'Cmd+R', role: 'reload' },
        { label: 'Toggle Developer Tools', accelerator: 'Cmd+Alt+I', role: 'toggleDevTools' }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// IPC Handlers
ipcMain.handle('get-api-catalog', () => {
  return API_CATALOG;
});

ipcMain.handle('get-active-integrations', () => {
  const profile = store.get(`profiles.${currentProfile}`, {});
  return profile.integrations || {};
});

ipcMain.handle('check-mcp-server', async () => {
  try {
    const mcpPath = store.get('mcpServerPath', path.join(process.env.HOME || '/Users/user', 'mcp-final'));
    const configPath = path.join(mcpPath, 'config.json');
    
    // Check if MCP directory and config exist
    if (fs.existsSync(configPath)) {
      return { connected: true, path: mcpPath };
    } else if (fs.existsSync(mcpPath)) {
      // Directory exists but no config - create one
      const defaultConfig = {
        integrations: {},
        profile: 'default',
        created: new Date().toISOString()
      };
      try {
        fs.writeFileSync(configPath, JSON.stringify(defaultConfig, null, 2));
        return { connected: true, path: mcpPath, created: true };
      } catch (e) {
        return { connected: false, error: 'Cannot create config' };
      }
    } else {
      return { connected: false, error: 'MCP server not found' };
    }
  } catch (error) {
    console.error('MCP server check error:', error);
    return { connected: false, error: error.message };
  }
});

ipcMain.handle('toggle-integration', async (event, serviceId, enabled) => {
  const profile = store.get(`profiles.${currentProfile}`, {});
  if (!profile.integrations) profile.integrations = {};
  
  profile.integrations[serviceId] = {
    enabled: enabled,
    toggledAt: new Date().toISOString()
  };
  
  store.set(`profiles.${currentProfile}`, profile);
  
  // Update MCP server configuration
  updateMCPConfiguration();
  
  return { success: true };
});

ipcMain.handle('save-api-key', async (event, serviceId, apiKey, metadata) => {
  try {
    // Use keytar for secure API key storage
    await keytar.setPassword('mcp-integration-hub', `${currentProfile}-${serviceId}`, apiKey);
    
    // Store metadata
    const profile = store.get(`profiles.${currentProfile}`, {});
    if (!profile.integrations) profile.integrations = {};
    profile.integrations[serviceId] = {
      ...profile.integrations[serviceId],
      configured: true,
      configuredAt: new Date().toISOString(),
      ...metadata
    };
    store.set(`profiles.${currentProfile}`, profile);
    
    // Log for audit trail
    console.log(`API key saved for ${serviceId} in profile ${currentProfile}`);
    
    // Update Docker bridge if running
    updateDockerBridge();
    
    return { success: true };
  } catch (error) {
    console.error(`Failed to save API key for ${serviceId}:`, error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('start-docker-bridge', async () => {
  try {
    const { exec } = require('child_process');
    const dockerComposePath = path.join(__dirname, 'docker-compose.yml');
    
    return new Promise((resolve) => {
      exec(`docker-compose -f "${dockerComposePath}" up -d`, (error, stdout, stderr) => {
        if (error) {
          console.error('Docker bridge error:', error);
          resolve({ success: false, error: error.message });
        } else {
          console.log('Docker bridge started successfully');
          resolve({ success: true, output: stdout });
        }
      });
    });
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('check-docker-bridge', async () => {
  try {
    const { exec } = require('child_process');
    
    return new Promise((resolve) => {
      exec('docker ps --filter name=mcp-security-bridge --format "{{.Status}}"', (error, stdout) => {
        if (error || !stdout.includes('healthy')) {
          resolve({ running: false });
        } else {
          resolve({ running: true, status: stdout.trim() });
        }
      });
    });
  } catch (error) {
    return { running: false, error: error.message };
  }
});

async function updateDockerBridge() {
  // Export keys to Docker environment
  const { exec } = require('child_process');
  const profile = store.get(`profiles.${currentProfile}`, {});
  
  // Create temporary env file for Docker
  const envContent = [];
  
  for (const [serviceId, config] of Object.entries(profile.integrations || {})) {
    if (config.configured) {
      try {
        const apiKey = await keytar.getPassword('mcp-integration-hub', `${currentProfile}-${serviceId}`);
        if (apiKey) {
          const envKey = config.envKey || `${serviceId.toUpperCase()}_API_KEY`;
          envContent.push(`${envKey}=${apiKey}`);
        }
      } catch (e) {
        console.error(`Failed to export key for ${serviceId}:`, e);
      }
    }
  }
  
  // Write to .env.docker
  const envPath = path.join(__dirname, '.env.docker');
  fs.writeFileSync(envPath, envContent.join('\n'), { mode: 0o600 });
  
  // Restart Docker container to load new keys
  exec('docker-compose restart', (error) => {
    if (error) {
      console.error('Failed to restart Docker bridge:', error);
    } else {
      console.log('Docker bridge updated with new keys');
    }
    
    // Clean up env file after Docker loads it
    setTimeout(() => {
      fs.unlinkSync(envPath);
    }, 5000);
  });
}

ipcMain.handle('get-api-key', async (event, serviceId) => {
  try {
    const apiKey = await keytar.getPassword('mcp-integration-hub', `${currentProfile}-${serviceId}`);
    return { success: true, key: apiKey };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('test-api-connection', async (event, serviceId, endpoint, headers) => {
  try {
    // Make test request to API endpoint
    const { net } = require('electron');
    const request = net.request({
      method: 'GET',
      url: endpoint
    });
    
    // Add headers
    Object.entries(headers || {}).forEach(([key, value]) => {
      request.setHeader(key, value);
    });
    
    return new Promise((resolve) => {
      request.on('response', (response) => {
        resolve({ success: response.statusCode === 200, status: response.statusCode });
      });
      
      request.on('error', (error) => {
        resolve({ success: false, error: error.message });
      });
      
      request.end();
    });
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-current-profile', () => {
  return currentProfile;
});

ipcMain.handle('switch-profile', (event, profileName) => {
  switchProfile(profileName);
  return { success: true, profile: profileName };
});

ipcMain.handle('get-usage-stats', async () => {
  // This would connect to your Claude usage tracking system
  // For now, return mock data with slight variations
  const base = store.get('usageStats', { credits: 1234, usage: 45.6, limit: 5000 });
  
  return {
    credits: base.credits + Math.floor(Math.random() * 10),
    usage: base.usage + (Math.random() * 2),
    limit: base.limit,
    lastUpdated: new Date().toISOString()
  };
});

function switchProfile(profileName) {
  currentProfile = profileName;
  store.set('currentProfile', profileName);
  mainWindow.webContents.send('profile-switched', profileName);
  updateMCPConfiguration();
}

function updateMCPConfiguration() {
  // Update the MCP server configuration at ~/mcp-final/
  const mcpPath = store.get('mcpServerPath', path.join(process.env.HOME, 'mcp-final'));
  const mcpConfigPath = path.join(mcpPath, 'config.json');
  const profile = store.get(`profiles.${currentProfile}`, {});
  const activeIntegrations = {};
  
  for (const [serviceId, config] of Object.entries(profile.integrations || {})) {
    if (config.enabled && config.configured) {
      activeIntegrations[serviceId] = true;
    }
  }
  
  // Write configuration (in real implementation, merge with existing)
  try {
    // Ensure directory exists
    if (!fs.existsSync(mcpPath)) {
      fs.mkdirSync(mcpPath, { recursive: true });
    }
    
    let existingConfig = {};
    
    // Read existing config if it exists
    if (fs.existsSync(mcpConfigPath)) {
      try {
        existingConfig = JSON.parse(fs.readFileSync(mcpConfigPath, 'utf8'));
      } catch (e) {
        console.error('Error reading existing MCP config:', e);
        existingConfig = {};
      }
    }
    
    // Merge with new configuration
    existingConfig.integrations = activeIntegrations;
    existingConfig.profile = currentProfile;
    existingConfig.lastUpdated = new Date().toISOString();
    
    // Write updated configuration
    fs.writeFileSync(mcpConfigPath, JSON.stringify(existingConfig, null, 2));
    console.log(`MCP configuration updated for profile: ${currentProfile}`);
  } catch (error) {
    console.error('Error updating MCP configuration:', error);
    
    // Show user-friendly error dialog
    dialog.showErrorBox('Configuration Error', 
      `Could not update MCP server configuration.\n\nPath: ${mcpConfigPath}\nError: ${error.message}`);
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
