// Health check for MCP Security Bridge
const http = require('http');

const options = {
    hostname: '127.0.0.1',
    port: 3000,
    path: '/health',
    method: 'GET',
    timeout: 2000
};

const req = http.request(options, (res) => {
    if (res.statusCode === 200) {
        process.exit(0);  // Healthy
    } else {
        process.exit(1);  // Unhealthy
    }
});

req.on('error', () => {
    process.exit(1);  // Unhealthy
});

req.on('timeout', () => {
    process.exit(1);  // Unhealthy
});

req.end();
