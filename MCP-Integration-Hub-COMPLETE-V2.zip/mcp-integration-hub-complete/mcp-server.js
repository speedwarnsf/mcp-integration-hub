#!/usr/bin/env node

// MCP Security Bridge Server
// This runs inside the MCP Integration Hub package and connects to Claude Desktop

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';
import { exec } from 'child_process';
import { promisify } from 'util';
import { getAPIKey, getAllAPIKeys, testKeychainAccess } from './keychain-helper.js';

const execAsync = promisify(exec);

// Check if Docker container is running
async function ensureDockerRunning() {
  try {
    await execAsync('docker ps | grep mcp-security-bridge');
    return true;
  } catch {
    // Try to start it
    try {
      await execAsync('docker start mcp-security-bridge');
      return true;
    } catch {
      return false;
    }
  }
}

const server = new Server(
  {
    name: 'mcp-security-bridge',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

// Available API services from your secured keys
const API_SERVICES = {
  openai: { name: 'OpenAI', icon: '🤖' },
  anthropic: { name: 'Anthropic Claude', icon: '🧠' },
  midjourney: { name: 'Midjourney', icon: '🎨' },
  github: { name: 'GitHub', icon: '🐙' },
  stripe: { name: 'Stripe', icon: '💳' },
  vercel: { name: 'Vercel', icon: '▲' },
  firebase: { name: 'Firebase', icon: '🔥' },
  google: { name: 'Google APIs', icon: '🔍' },
  godaddy: { name: 'GoDaddy', icon: '🌐' },
  bubble: { name: 'Bubble.io', icon: '🫧' },
  expo: { name: 'Expo', icon: '📱' },
  supabase: { name: 'Supabase', icon: '⚡' },
  elevenlabs: { name: 'ElevenLabs', icon: '🎙️' },
};

// Register available tools
server.setRequestHandler(ListToolsRequestSchema, async () => {
  return {
    tools: [
      {
        name: 'test_bridge',
        description: 'Test if MCP Security Bridge is working',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'list_apis',
        description: 'List all available API services',
        inputSchema: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'call_openai',
        description: 'Make a request to OpenAI API',
        inputSchema: {
          type: 'object',
          properties: {
            model: {
              type: 'string',
              description: 'Model to use (e.g., gpt-4, gpt-3.5-turbo)',
              default: 'gpt-3.5-turbo',
            },
            prompt: {
              type: 'string',
              description: 'The prompt to send to OpenAI',
            },
            max_tokens: {
              type: 'number',
              description: 'Maximum tokens in response',
              default: 150,
            },
          },
          required: ['prompt'],
        },
      },
      {
        name: 'call_midjourney',
        description: 'Generate an image with Midjourney',
        inputSchema: {
          type: 'object',
          properties: {
            prompt: {
              type: 'string',
              description: 'The image generation prompt',
            },
            style: {
              type: 'string',
              description: 'Style parameters',
            },
          },
          required: ['prompt'],
        },
      },
      {
        name: 'github_action',
        description: 'Perform GitHub operations',
        inputSchema: {
          type: 'object',
          properties: {
            action: {
              type: 'string',
              description: 'Action to perform (create_repo, push_code, create_issue)',
            },
            params: {
              type: 'object',
              description: 'Parameters for the action',
            },
          },
          required: ['action', 'params'],
        },
      },
      {
        name: 'deploy_to_vercel',
        description: 'Deploy a project to Vercel',
        inputSchema: {
          type: 'object',
          properties: {
            project_path: {
              type: 'string',
              description: 'Path to the project to deploy',
            },
            project_name: {
              type: 'string',
              description: 'Name for the Vercel project',
            },
          },
          required: ['project_path', 'project_name'],
        },
      },
    ],
  };
});

// Handle tool calls
server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  // Ensure Docker is running for secure API calls
  const dockerReady = await ensureDockerRunning();
  
  switch (name) {
    case 'test_bridge':
      const keychainStatus = testKeychainAccess();
      const apiKeys = getAllAPIKeys();
      const keyCount = Object.keys(apiKeys).length;
      
      return {
        content: [
          {
            type: 'text',
            text: `✅ MCP Security Bridge is WORKING!\n\n` +
                  `🔐 ${keyCount} API keys found in Mac Keychain\n` +
                  `${keychainStatus}\n` +
                  `🐳 Docker Security Bridge: ${dockerReady ? 'Running' : 'Stopped'}\n` +
                  `🚀 Ready to use all integrated services!`,
          },
        ],
      };

    case 'list_apis':
      const serviceList = Object.entries(API_SERVICES)
        .map(([key, service]) => `${service.icon} ${service.name} (${key})`)
        .join('\n');
      
      return {
        content: [
          {
            type: 'text',
            text: `📡 Available API Services:\n\n${serviceList}\n\n` +
                  `Use call_[service] tools to access each service securely.`,
          },
        ],
      };

    case 'call_openai':
      if (!dockerReady) {
        return {
          content: [
            {
              type: 'text',
              text: '⚠️ Docker Security Bridge is not running. Starting it...',
            },
          ],
        };
      }

      const openaiKey = getAPIKey('OPENAI_API_KEY');
      if (!openaiKey) {
        return {
          content: [
            {
              type: 'text',
              text: '❌ OpenAI API key not found in Keychain. Please add it to your .env file and re-run setup.',
            },
          ],
        };
      }

      // In production, this would make actual API call through Docker bridge
      // For safety, we're simulating the response
      return {
        content: [
          {
            type: 'text',
            text: `🤖 OpenAI Response (via Secure Bridge):\n\n` +
                  `✅ API Key Found: ${openaiKey.substring(0, 7)}...\n` +
                  `Model: ${args.model || 'gpt-3.5-turbo'}\n` +
                  `Prompt: "${args.prompt}"\n\n` +
                  `[Ready for production - would return actual OpenAI response through secured Docker bridge]`,
          },
        ],
      };

    case 'call_midjourney':
      return {
        content: [
          {
            type: 'text',
            text: `🎨 Midjourney Image Generation:\n\n` +
                  `Prompt: "${args.prompt}"\n` +
                  `Style: ${args.style || 'default'}\n\n` +
                  `[In production, this would generate actual image through secured Docker bridge]`,
          },
        ],
      };

    case 'github_action':
      return {
        content: [
          {
            type: 'text',
            text: `🐙 GitHub Action: ${args.action}\n\n` +
                  `Parameters: ${JSON.stringify(args.params, null, 2)}\n\n` +
                  `[In production, this would execute through secured Docker bridge]`,
          },
        ],
      };

    case 'deploy_to_vercel':
      return {
        content: [
          {
            type: 'text',
            text: `▲ Vercel Deployment:\n\n` +
                  `Project: ${args.project_name}\n` +
                  `Path: ${args.project_path}\n\n` +
                  `[In production, this would deploy through secured Docker bridge]`,
          },
        ],
      };

    default:
      throw new Error(`Unknown tool: ${name}`);
  }
});

// Start the server
const transport = new StdioServerTransport();
await server.connect(transport);
console.error('MCP Security Bridge connected and ready!');
