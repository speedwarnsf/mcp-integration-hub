const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('mcpHub', {
  // API Catalog
  getAPICatalog: () => ipcRenderer.invoke('get-api-catalog'),
  getActiveIntegrations: () => ipcRenderer.invoke('get-active-integrations'),
  
  // MCP Server
  checkMCPServer: () => ipcRenderer.invoke('check-mcp-server'),
  
  // Integration Management
  toggleIntegration: (serviceId, enabled) => 
    ipcRenderer.invoke('toggle-integration', serviceId, enabled),
  saveAPIKey: (serviceId, apiKey, metadata) => 
    ipcRenderer.invoke('save-api-key', serviceId, apiKey, metadata),
  getAPIKey: (serviceId) => 
    ipcRenderer.invoke('get-api-key', serviceId),
  testAPIConnection: (serviceId, endpoint, headers) =>
    ipcRenderer.invoke('test-api-connection', serviceId, endpoint, headers),
  
  // Profile Management
  getCurrentProfile: () => ipcRenderer.invoke('get-current-profile'),
  switchProfile: (profileName) => ipcRenderer.invoke('switch-profile', profileName),
  
  // Usage Tracking
  getUsageStats: () => ipcRenderer.invoke('get-usage-stats'),
  
  // Docker Bridge Management
  startDockerBridge: () => ipcRenderer.invoke('start-docker-bridge'),
  checkDockerBridge: () => ipcRenderer.invoke('check-docker-bridge'),
  
  // Event Listeners
  onProfileSwitched: (callback) => {
    ipcRenderer.on('profile-switched', (event, profile) => callback(profile));
  },
  onOpenPreferences: (callback) => {
    ipcRenderer.on('open-preferences', () => callback());
  },
  onManageProfiles: (callback) => {
    ipcRenderer.on('manage-profiles', () => callback());
  }
});
